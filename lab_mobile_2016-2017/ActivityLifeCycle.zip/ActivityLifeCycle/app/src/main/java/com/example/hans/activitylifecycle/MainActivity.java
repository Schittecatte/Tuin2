package com.example.hans.activitylifecycle;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private static final String MY_TAG ="MyActivity";

    String message="empty";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.v(MY_TAG,"onCreate");
        setContentView(R.layout.activity_main);

        Button button=(Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = (EditText) findViewById(R.id.editText);
                message=editText.getText().toString();

                TextView textView = (TextView) findViewById(R.id.textView);
                textView.setText(message);
            }
        });
    }

    public void onClickGet(View v)
    {
        TextView textView = (TextView) findViewById(R.id.textView);
        textView.setText(message);
    }



    @Override
    protected void onStart() {
        super.onStart();
        Log.v(MY_TAG,"onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v(MY_TAG,"onResume");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(MY_TAG,"onPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.v(MY_TAG,"onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(MY_TAG,"onDestroy");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.v(MY_TAG,"onRestart");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.v(MY_TAG,"onSaveInstanceState");
        outState.putString("message",message);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.v(MY_TAG,"onRestoreInstanceState");
        message=savedInstanceState.getString("message");
    }
}
