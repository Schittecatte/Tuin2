package com.example.hans.fragments;

import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity implements BlankFragment.ActivityInterface
{

    SecondFragment secondFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        secondFragment = new SecondFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

        fragmentTransaction.add(R.id.activity_main,secondFragment);

        fragmentTransaction.addToBackStack(null);

        fragmentTransaction.commit();

    }

    public void onClick(View v)
    {
        BlankFragment blankFragment= (BlankFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_blank);

        blankFragment.SendMessage("Test");
    }

    public void SendMessage(String message)
    {
        //Toast.makeText(this,message, Toast.LENGTH_LONG).show();
        secondFragment.SendMessage2(message);
    }
}
