package com.example.niels.opdracht2a;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the content of the activity to use the activity_main.xml layout file
        setContentView(R.layout.activity_main);
        TextView belgium = (TextView)findViewById(R.id.belgium);
        belgium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent belgiumIntent = new Intent(MainActivity.this, Belgium.class);
                startActivity(belgiumIntent);
            }
        });

        TextView netherlands = (TextView)findViewById(R.id.netherlands);
        netherlands.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent netherlandsIntent = new Intent(MainActivity.this, Netherlands.class);
                startActivity(netherlandsIntent);
            }
        });

        TextView france = (TextView)findViewById(R.id.france);
        france.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent franceIntent = new Intent(MainActivity.this, France.class);
                startActivity(franceIntent);
            }
        });

        TextView spain = (TextView)findViewById(R.id.spain);
        spain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent spainIntent = new Intent(MainActivity.this, Spain.class);
                startActivity(spainIntent);
            }
        });


    }

}