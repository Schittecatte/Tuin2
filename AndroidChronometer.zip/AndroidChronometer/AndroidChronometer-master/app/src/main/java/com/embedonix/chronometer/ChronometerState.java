package com.embedonix.chronometer;
public enum ChronometerState {

    STOPPED,
    RUNNING,
    IN_BACKGROUND
}
